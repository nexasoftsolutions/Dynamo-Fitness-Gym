---
name: Kinetic Obsidian
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c4c9ac'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#8e9379'
  outline-variant: '#444933'
  surface-tint: '#abd600'
  primary: '#ffffff'
  on-primary: '#283500'
  primary-container: '#c3f400'
  on-primary-container: '#556d00'
  inverse-primary: '#506600'
  secondary: '#ffb3af'
  on-secondary: '#68000e'
  secondary-container: '#ff5357'
  on-secondary-container: '#5c000b'
  tertiary: '#ffffff'
  on-tertiary: '#21323e'
  tertiary-container: '#d2e5f5'
  on-tertiary-container: '#556774'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c3f400'
  primary-fixed-dim: '#abd600'
  on-primary-fixed: '#161e00'
  on-primary-fixed-variant: '#3c4d00'
  secondary-fixed: '#ffdad8'
  secondary-fixed-dim: '#ffb3af'
  on-secondary-fixed: '#410006'
  on-secondary-fixed-variant: '#930019'
  tertiary-fixed: '#d2e5f5'
  tertiary-fixed-dim: '#b6c9d8'
  on-tertiary-fixed: '#0b1d29'
  on-tertiary-fixed-variant: '#374956'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-xl:
    fontFamily: anybody
    fontSize: 96px
    fontWeight: '800'
    lineHeight: 90%
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: anybody
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 100%
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: anybody
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 105%
  headline-md:
    fontFamily: anybody
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 110%
  body-lg:
    fontFamily: hankenGrotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 160%
  body-md:
    fontFamily: hankenGrotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 150%
  label-caps:
    fontFamily: spaceMono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 100%
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  bento-gap: 12px
---

## Brand & Style

The design system is built for an elite fitness environment that merges the raw, unyielding energy of **Modern Brutalism** with the sophisticated precision of **High-End Editorial** design. It is designed to evoke a sense of "premium grit"—the feeling of an exclusive, high-performance underground facility.

The aesthetic leans heavily on high-contrast visuals, using vast expanses of deep obsidian to make neon accents feel electric. Layouts should feel intentional and structural, utilizing asymmetrical "Bento Box" grids that break standard patterns to create a sense of movement and dynamic power. Visual interest is maintained through subtle grain/noise textures on dark surfaces and sharp, technical details that contrast with frosted, glassmorphic overlays.

## Colors

The palette is dominated by **Obsidian (#0A0A0A)**, providing a void-like depth that serves as the canvas for high-intensity highlights.

- **Electric Neon (#CCFF00):** Used for primary actions, progress indicators, and "active state" highlights. It represents energy and kinetic potential.
- **Vibrant Crimson (#FF0033):** Reserved for high-alert elements, elite "Pro" tier features, heart-rate zones, and aggressive branding accents.
- **Surface Hierarchy:** Backgrounds use the base Obsidian. Cards and containers use a slightly elevated "Carbon" (#1A1A1A) with semi-transparency and backdrop blurring to achieve the glassmorphic effect.

All interactions should maintain a high contrast ratio to ensure legibility against the dark backdrop.

## Typography

Typography in the design system is aggressive and structural. 

- **Headlines:** Use *Anybody*. It should be set with tight leading and negative letter spacing to create a "blocky," impactful look. Display sizes should almost always be uppercase to reinforce the brutalist editorial feel.
- **Body Copy:** *Hanken Grotesk* provides a clean, geometric balance to the aggressive headings, ensuring that workout data and instructional text are highly readable.
- **Data & Labels:** *Space Mono* is used for technical data (reps, sets, timers) and small utility labels, nodding to the precision of athletic performance tracking.

## Layout & Spacing

The layout follows an **Asymmetrical Bento-Box Grid**. This approach uses fixed-aspect ratio containers of varying sizes packed tightly together, creating a modern, data-dense editorial feel.

- **Grid:** Use a 12-column grid for desktop and a 4-column grid for mobile.
- **Rhythm:** Spacing should be strictly mathematical, based on a 4px baseline.
- **Asymmetry:** Avoid perfectly symmetrical split-screens. Instead, use a 60/40 or 70/30 split to create visual tension.
- **Negative Space:** While the bento boxes are packed, allow for large "breathing zones" of pure Obsidian between major sections to maintain a premium, gallery-like feel.

## Elevation & Depth

This design system eschews traditional soft shadows in favor of **Tonal Layering** and **Glassmorphism**.

1.  **Base Layer:** Solid Obsidian (#0A0A0A) with a subtle noise texture (3-5% opacity).
2.  **Morphic Layer:** Semi-transparent Carbon (#1A1A1A at 60% opacity) with a heavy backdrop blur (20px-40px). This is used for cards and navigation bars.
3.  **Accent Borders:** Instead of shadows, use 1px inner borders (strokes). For inactive elements, use a subtle grey (#262626). For active or "hot" elements, use a 1px solid stroke of Electric Neon.
4.  **Glow:** Reserve soft, diffused outer glows only for the Primary color (#CCFF00) to simulate neon lighting in a dark gym environment.

## Shapes

The shape language is "Soft-Brutalist." While traditional brutalism is sharp, this design system introduces a subtle 0.25rem (4px) radius to soften the edges of the high-contrast blocks, making the UI feel "engineered" rather than "unfinished."

- **Containers:** 4px (Soft) corner radius for most cards and bento units.
- **Interactive Elements:** Buttons and input fields follow the 4px standard. 
- **Exceptions:** Progress bars and data chips may use a full pill-shape (radius 999px) to contrast against the rigid rectangular grid.

## Components

- **Buttons:** Primary buttons are solid Electric Neon with black text, using the `label-caps` font style. Secondary buttons are ghost-style with a 1px Neon stroke.
- **Bento Cards:** These are the core organizational unit. They should feature a 1px border and the glassmorphic backdrop-blur effect. Content within should be pinned to the corners for an editorial look.
- **Inputs:** Dark backgrounds with a 1px bottom-border only. When focused, the border transforms into a solid Electric Neon line with a slight neon glow.
- **Lists:** High-density rows with thin separators. Use `spaceMono` for numerical data on the right-hand side of list items.
- **Chips/Badges:** Small, rectangular tags with no border-radius (sharp corners) to denote "Elite," "Pro," or "Sold Out" status, usually in Crimson or Neon.
- **Workout Stats:** Large, oversized `display-xl` numbers for metrics like "BPM" or "Calories," positioned behind other elements at a low opacity to act as a background graphic.